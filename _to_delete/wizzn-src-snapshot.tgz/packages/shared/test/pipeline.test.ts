import { describe, expect, it } from 'vitest'
import { draftAudioSchema, draftWrittenSchema, evaluateCheck, imagePickSchema, scheduleImages } from '../src/pipeline.js'

const ok = [{ url: 'https://a.de', ok: true, status: 200 }]

describe('evaluateCheck', () => {
  it('passes when all claims are sourced and links work', () => {
    expect(evaluateCheck({ claims: [{ text: 'x', sourceIndex: 0 }], issues: [] }, ok).passed).toBe(true)
  })
  it('fails on an unsupported claim', () => {
    const r = evaluateCheck({ claims: [{ text: 'x', sourceIndex: null }], issues: [] }, ok)
    expect(r.passed).toBe(false)
    expect(r.unsupportedClaims).toBe(1)
  })
  it('fails on a high-severity issue or dead link, not on a low one', () => {
    expect(evaluateCheck({ claims: [], issues: [{ severity: 'high', message: 'm' }] }, ok).passed).toBe(false)
    expect(evaluateCheck({ claims: [], issues: [{ severity: 'low', message: 'm' }] }, ok).passed).toBe(true)
    expect(evaluateCheck({ claims: [], issues: [] }, [{ url: 'u', ok: false, status: 404 }]).passed).toBe(false)
  })
})

describe('scheduleImages', () => {
  it('maps fractions to seconds inside the duration', () => {
    expect(scheduleImages(200, [0, 0.5, 0.95])).toEqual([0, 100, 190])
    expect(scheduleImages(10, [1])).toEqual([9])
  })
})

describe('draftAudioSchema', () => {
  const words = (n: number) => Array(n).fill('wort').join(' ')
  it('enforces 420–700 words', () => {
    const base = { title: 'Titel', images: [{ prompt: 'eine Zeichnung', atFraction: 0 }] }
    expect(draftAudioSchema.safeParse({ ...base, script: words(500) }).success).toBe(true)
    expect(draftAudioSchema.safeParse({ ...base, script: words(419) }).success).toBe(false)
    expect(draftAudioSchema.safeParse({ ...base, script: words(701) }).success).toBe(false)
  })
})

describe('draftWrittenSchema imageQuery', () => {
  const slide = { title: 'T', body: 'kurzer Text' }
  const draft = (extra: object) => ({ title: 'Titel', slides: [{ ...slide, ...extra }, slide, slide] })
  it('accepts slides with and without imageQuery', () => {
    expect(draftWrittenSchema.safeParse(draft({})).success).toBe(true)
    expect(draftWrittenSchema.safeParse(draft({ imageQuery: 'apple tree' })).success).toBe(true)
  })
  it('drops too short and truncates too long imageQuery instead of failing the draft', () => {
    expect(draftWrittenSchema.parse(draft({ imageQuery: 'x' })).slides[0]!.imageQuery).toBeUndefined()
    expect(draftWrittenSchema.parse(draft({ imageQuery: 'x'.repeat(41) })).slides[0]!.imageQuery).toBe('x'.repeat(40))
  })
})

describe('draftAudioSchema image query', () => {
  const words = (n: number) => Array(n).fill('wort').join(' ')
  const draft = (image: object) => ({ title: 'Titel', script: words(500), images: [image] })
  it('accepts optional images[].query', () => {
    expect(draftAudioSchema.safeParse(draft({ prompt: 'eine Zeichnung', atFraction: 0 })).success).toBe(true)
    expect(draftAudioSchema.safeParse(draft({ prompt: 'eine Zeichnung', atFraction: 0, query: 'apple tree' })).success).toBe(true)
    expect(draftAudioSchema.parse(draft({ prompt: 'eine Zeichnung', atFraction: 0, query: 'x' })).images[0]!.query).toBeUndefined()
  })
})

describe('imagePickSchema', () => {
  it('accepts an index or null', () => {
    expect(imagePickSchema.safeParse({ index: 2 }).success).toBe(true)
    expect(imagePickSchema.safeParse({ index: null }).success).toBe(true)
    expect(imagePickSchema.safeParse({ index: -1 }).success).toBe(false)
  })
})

describe('draft image hints are lenient (small local models)', () => {
  const body = 'Kurzer Text.'
  const slide = (extra: Record<string, unknown>) => ({ title: 'T', body, ...extra })
  const draft = (extra: Record<string, unknown>) => ({ title: 'Titel', slides: [slide(extra), slide({}), slide({})] })

  it('treats null and empty strings as absent', () => {
    const d = draftWrittenSchema.parse(draft({ imagePrompt: null, imageQuery: '' }))
    expect(d.slides[0]!.imagePrompt).toBeUndefined()
    expect(d.slides[0]!.imageQuery).toBeUndefined()
  })

  it('joins array queries and clamps them to 40 chars at a word boundary', () => {
    const d = draftWrittenSchema.parse(draft({ imagePrompt: 'Eier auf Holztisch', imageQuery: ['eggs', 'beans'] }))
    expect(d.slides[0]!.imageQuery).toBe('eggs beans')
    const long = draftWrittenSchema.parse(draft({ imageQuery: 'grilled chicken breast lentils chickpeas tofu' }))
    expect(long.slides[0]!.imageQuery).toBe('grilled chicken breast lentils chickpeas')
  })

  it('applies the same leniency to audio image queries', () => {
    const script = Array.from({ length: 450 }, () => 'wort').join(' ')
    const d = draftAudioSchema.parse({ title: 'Titel', script, images: [{ prompt: 'Ein Teller', query: null, atFraction: 0.1 }] })
    expect(d.images[0]!.query).toBeUndefined()
  })
})

describe('draftAudioSchema word count message', () => {
  it('reports the actual word count and direction', () => {
    const r = draftAudioSchema.safeParse({ title: 'Titel', script: Array(300).fill('wort').join(' '), images: [{ prompt: 'Ein Teller', atFraction: 0 }] })
    expect(r.success).toBe(false)
    expect(r.error!.issues[0]!.message).toContain('has 300 (expand)')
  })
})
