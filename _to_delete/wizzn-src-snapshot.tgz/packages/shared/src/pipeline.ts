import { z } from 'zod'

const words = (s: string): number => s.trim().split(/\s+/).filter(Boolean).length

/** German TTS speaks ~140 words/min → 420–700 words ≈ 3–5 min (spec §1). */
export const AUDIO_SCRIPT_WORDS = { min: 420, max: 700 } as const

/**
 * Optional free-text hint from the LLM (image prompt / stock query). Small local models send null, "",
 * arrays of terms or overlong strings; a bad hint must not fail the whole draft, so normalise instead of reject.
 */
const hint = (min: number, max?: number) =>
  z.preprocess(
    (v) => {
      if (v == null) return undefined
      const raw = Array.isArray(v) ? v.filter((x) => typeof x === 'string').join(' ') : v
      if (typeof raw !== 'string') return raw
      let s = raw.replace(/\s+/g, ' ').trim()
      if (s.length < min) return undefined
      if (max && s.length > max) {
        const cut = s.slice(0, max + 1).lastIndexOf(' ')
        s = (cut > 0 ? s.slice(0, cut) : s.slice(0, max)).trim()
      }
      return s
    },
    (max ? z.string().min(min).max(max) : z.string().min(min)).optional(),
  )

export const draftWrittenSchema = z.object({
  title: z.string().min(3).max(80),
  slides: z
    .array(
      z.object({
        title: z.string().min(1).max(80),
        body: z.string().min(1).refine((b) => words(b) <= 60, { message: 'Slide body exceeds 60 words' }),
        imagePrompt: hint(3),
        imageQuery: hint(2, 40),
      }),
    )
    .min(3)
    .max(5),
})
export type DraftWritten = z.infer<typeof draftWrittenSchema>

export const draftAudioSchema = z.object({
  title: z.string().min(3).max(80),
  // LLMs can't count words: report the actual count so the repair round knows whether to expand or cut
  script: z.string().superRefine((s, ctx) => {
    const n = words(s)
    if (n < AUDIO_SCRIPT_WORDS.min || n > AUDIO_SCRIPT_WORDS.max)
      ctx.addIssue({ code: 'custom', message: `Script must have ${AUDIO_SCRIPT_WORDS.min}–${AUDIO_SCRIPT_WORDS.max} words, has ${n} (${n < AUDIO_SCRIPT_WORDS.min ? 'expand' : 'shorten'})` })
  }),
  images: z
    .array(z.object({ prompt: z.string().min(3), query: hint(2, 40), atFraction: z.number().min(0).max(0.95) }))
    .min(1)
    .max(3),
})
export type DraftAudio = z.infer<typeof draftAudioSchema>

export const sourcePickSchema = z.object({
  picks: z.array(z.object({ index: z.number().int().min(0), publisher: z.string().min(1) })).min(1).max(3),
})
export type SourcePick = z.infer<typeof sourcePickSchema>

export const imagePickSchema = z.object({ index: z.number().int().min(0).nullable() })
export type ImagePick = z.infer<typeof imagePickSchema>

export const llmCheckSchema = z.object({
  claims: z.array(z.object({ text: z.string(), sourceIndex: z.number().int().min(0).nullable() })),
  issues: z.array(z.object({ severity: z.enum(['low', 'high']), message: z.string() })),
})
export type LlmCheck = z.infer<typeof llmCheckSchema>

export interface CheckReport extends LlmCheck {
  links: { url: string; ok: boolean; status: number | null }[]
  unsupportedClaims: number
  passed: boolean
}

/** Spec §4: unsupported claims, high-severity issues or dead links fail the check (unit still goes to human review). */
export function evaluateCheck(llm: LlmCheck, links: CheckReport['links']): CheckReport {
  const unsupportedClaims = llm.claims.filter((c) => c.sourceIndex === null).length
  const passed = unsupportedClaims === 0 && !llm.issues.some((i) => i.severity === 'high') && links.every((l) => l.ok)
  return { ...llm, links, unsupportedClaims, passed }
}

/** Converts draft image fractions into whole seconds inside the audio (audioUnitSchema requires showAtSec < duration). */
export function scheduleImages(durationSec: number, fractions: number[]): number[] {
  return fractions.map((f) => Math.min(Math.max(0, Math.floor(f * durationSec)), Math.max(0, durationSec - 1)))
}
